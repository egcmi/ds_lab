import java.rmi.*;

public class AdditionClient {
	
	public static void main (String[] args) throws Exception {
		AdderInterface obj;
		System.setSecurityManager(new SecurityManager());
		obj = (AdderInterface)Naming.lookup("rmi://localhost/ourAdder");
		int result = obj.add(9,345);
		System.out.println("Result is: " + result);
	}
}